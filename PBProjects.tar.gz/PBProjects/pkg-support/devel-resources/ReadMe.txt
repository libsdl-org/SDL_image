This is an example portable network library for use with SDL.
The API can be found in the file SDL_image.h

The source code is available from: http://www.libsdl.org/projects/SDL_image

This library is distributed under the terms of the GNU LGPL license: http://www.gnu.org/copyleft/lesser.html
